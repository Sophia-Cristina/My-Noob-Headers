;---------------------------------------------------------------------------------------------------
;
; Calculating Pi using the inverse tangent formula with Intel 4004 CPU (MCS-4 system) to 16 digits.
;
; Written by Lajos Kintli.
;
; (version 2023.10.29)
;
;---------------------------------------------------------------------------------------------------
;
; Used formulas:
;
;	Euler:		Pi/4 = arc tg (1/2) + arc tg (1/3)
;
;	Better:		Pi/4 = 2 * arc tg (1/3) + arc tg (1/7)
;
;	Machin's:	Pi/4 = 4 * arc tg (1/5) - arc tg (1/239)
;
; Inverse tangent is calculated using the Taylor polynomial: 
;
;	arc tg(x)=x - x^3/3 + x^5/5 - x^7/7 + x^9/9 - x^11/11 + ...,
;
; what works for an integer reciprocal in the below way (x=1/n):
;  
;	arc tg(1/n)=1/n - 1/n^3/3 + 1/n^5/5 - 1/n^7/7 + 1/n^9/9 - 1/n^11/11 + ...
;
; Three high level registers are implemented, REG0 is for the sum, REG1 is for the next item
; in Taylor polynomial: 1/n^(2k+1)/(2k+1), while REG2 is for 1/n^(2k+1). 
;
; Precision is 16*4 bit in binary. During the arc tg calculation the integer part of the number
; is zero, only fractional part is stored in memory cells (decimal point is fixed before the first
; memory cell). 
;
; REG2 is started with 1/n, and divided by n*n at every iterations. REG1 is coming
; from REG2 divided by (2k+1).
;
; Binary result is converted to decimal at the end for 16 digits behind the decimal point
;
; Two divide routines are implemented, first is slightly faster and handles only 4 bit
; divider, while the other accepts 8 bit divider.
;
; Register usage:
;
; r0,r1		RAM pointer (target register)
; r2,r3		RAM pointer (source register)
; r4,r5		divider
; r6,r7		used for divide
; r8		length counter
; r9		bit counter
; ra		next 4 bits
; rb		sign bit or digit
; rc,rd:	2 k + 1
; re,rf:	n*n if n=2,3,7 or n=239 (highest bit decides if it is n or n*n)
; 
; ram 00-0f:	REG0: sum
; ram 10-1f:	REG1: 1/n^(2k+1)/(2k+1)
; ram 20-2f:	REG2: 1/n^(2k+1)
; ram 30-3f:	decimal result
;
; Result RAM0 content:
;	0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 - 0 0 0 0
;	0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 - 0 0 0 0
;	2 4 3 F 6 A 8 8 8 5 A 3 0 8 D 8 - 0 0 0 0	<-- fractional in hex
;	1 4 1 5 9 2 6 5 3 5 8 9 7 9 3 2 - 0 0 0 3	<-- decimal
;
;---------------------------------------------------------------------------------------------------

; Set one of the below definitions to 1!

EULER		EQU	0
BETTER		EQU	0
MACHIN		EQU	1

; Enable 7 segment digit

DISPLAY		EQU	1

		org	0

		nop
		jun	start

;---------------------------------------------------------------------------------------------------
; ADD:	[DST] = [DST] + [SRC]
;---------------------------------------------------------------------------------------------------

add_xy:		clc
add_loop:	src	2
		rdm
		src	0
		adm
		wrm
		inc	3
		isz	1,add_loop
		bbl	0

;---------------------------------------------------------------------------------------------------
; SUB:	[DST] = [DST] - [SRC]
;---------------------------------------------------------------------------------------------------
sub_xy:		clc
sub_loop:	src	0
		rdm
		src	2
		sbm
		cmc
		src	0
		wrm
		inc	3
		isz	1,sub_loop
		bbl	0

;---------------------------------------------------------------------------------------------------
; FILL:	[DST] = value
;---------------------------------------------------------------------------------------------------

storez:		ldm	0			
store:		src	0
		wrm
		isz	1,store
		bbl	0
		
;---------------------------------------------------------------------------------------------------
; MOV:	[DST] = [SRC]
;---------------------------------------------------------------------------------------------------

mov_xy:
mov_loop:	src	2
		rdm
		src	0
		wrm
		inc	3
		isz	1,mov_loop
		bbl	0

;---------------------------------------------------------------------------------------------------
; multiply by 2 - REG0 = 2 * REG0,  extra bits are in regB
;---------------------------------------------------------------------------------------------------

mul2:		fim	0,$00
		fim	2,$00
		jms	add_xy
		ld	$b
		ral
		xch	$b
		bbl	0	
		
;---------------------------------------------------------------------------------------------------
; Divide by a 4 bit value in r5:	[DST] = [DST] / reg5
;---------------------------------------------------------------------------------------------------
div_r:		clb

div_r_set:	fim	8,0

div_r_dloop:	xch	1	; data loop
		dac
		xch	1
		src	0

		xch	$a	; fetch next 4 bits into r7
		rdm
		xch	$a

		xch	9	; 4 bit counter
		ldm	$c
		xch	9
		
div_r_bloop:	clc		; bit loop
		xch	$a
		ral		; rotate accu - regA left by one bit
		xch	$a
		ral
		jc	div_r_sub
		
		sub	5	; try to sub the number
		jc	div_r_sub_ok
		
		add	5	; add back the number
		jun	div_r_skip

div_r_sub:	clc
		sub	5	; sub the number in case of carry
div_r_sub_ok:	inc	$a

div_r_skip:	isz	9,div_r_bloop

		xch	$a
		wrm
		xch	$a

		isz	8,div_r_dloop

		bbl	0

;---------------------------------------------------------------------------------------------------
; Divide 1 by an 8 bit value in r4, r5:	REG2 = 1 / reg4-reg5
;---------------------------------------------------------------------------------------------------
div_x_one	fim	0,$20
		jms	storez

		ld	4
		jnz	div_rr_one

div_r_one:	ldm	1
		jun	div_r_set

div_rr_one:	fim	6,1
		jun	div_rr_set


;---------------------------------------------------------------------------------------------------
; Divide by an 8 bit value in r4, r5:	[DST] = [DST] / reg4-reg5
;---------------------------------------------------------------------------------------------------
div_x:		ld	4
		jz	div_r

;---------------------------------------------------------------------------------------------------
; Divide by an 8 bit value in r4, r5:	[DST] = [DST] / reg4-reg5
;---------------------------------------------------------------------------------------------------
div_rr:		fim	6,0	; clear number
div_rr_set:	fim	8,0

div_rr_dloop:	xch	1	; data loop
		dac
		xch	1
		src	0

		rdm		; fetch next 4 bits into r7
		xch	$a

		ldm	$c	; 4 bit counter
		xch	9
		
div_rr_bloop:	clc		; bit loop
		xch	$a
		ral		; rotate reg6 - reg7 - regA left by one bit
		xch	$a
		xch	7
		ral
		xch	7
		xch	6
		ral
		xch	6
		
		jc	div_rr_sub
		
		xch	7	; try to sub the number
		sub	5
		xch	7
		cmc
		xch	6
		sub	4
		xch	6

		jc	div_rr_sub_ok
		
		xch	7	; add back the number
		add	5
		xch	7
		xch	6
		add	4
		xch	6

		jun	div_rr_skip

div_rr_sub:	clc		; sub the number in case of carry
		xch	7
		sub	5
		xch	7
		cmc
		xch	6
		sub	4
		xch	6

div_rr_sub_ok:	inc	$a

div_rr_skip:	isz	9,div_rr_bloop

		xch	$a
		wrm
		xch	$a

		isz	8,div_rr_dloop

		bbl	0

;---------------------------------------------------------------------------------------------------
; calculate arc tg (1/n)
; r4,r5 : n
; re,rf : n*n (or n if n>127)
;---------------------------------------------------------------------------------------------------

arc_tg:		ldm	0
arc_tg_m:	xch	$b		
		jms	div_x_one	; prepare 1/x

		fim	$c,1

		fim	0,$00
		fim	2,$20
		
		ld	$b
		rar
		jc	atg_minus
		
		jms	add_xy
		jun	atg_loop
		
atg_minus:	jms	sub_xy

atg_loop:
		IF	DISPLAY
		jms	dsp_reg0
		ENDIF

		clb			; next (2*k+1) 
		ldm	2
		add	$d
		xch	$d
		ldm	0
		add	$c
		xch	$c
		
		fim	0,$20		; REG2 = REG2 / n * n
		ld	$f
		xch	5
		ld	$e
		xch	4
		jms	div_x
		
		ld	$e
		ral
		jnc	atg_skpdiv
		
		jms	div_x		; in case of n>127 (n=239), another division is needed

atg_skpdiv:	fim	0,$10		; REG1 = REG2
		fim	2,$20
		jms	mov_xy

		ld	$d		; REG1 = REG1 / (2*k+1)
		xch	5
		ld	$c
		xch	4
		jms	div_x

atg_chk_loop:	src	0		; Check if REG1 is zero
		rdm
		jnz	atg_nz
		isz	1,atg_chk_loop

		bbl	0		; return, if number is zero
		
atg_nz:		fim	0,$00
		fim	2,$10
		
		inc	$b		; alternate add/sub functions
		ld	$b
		rar
		jc	atg_sub
		
		jms	add_xy		; REG0 = REG0 + REG1
		jun	atg_loop

atg_sub:	jms	sub_xy		; REG0 = REG0 - REG1
		jun	atg_loop
	
;---------------------------------------------------------------------------------------------------
; main program
;---------------------------------------------------------------------------------------------------

start:		fim	0,$0
		jms	storez

		IF EULER

; arc tg (1/2) + arc tg (1/3)

 
		fim	4,3		; prepare 3 & 9
		fim	$e,9
		jms	arc_tg

		fim	4,2		; prepare 2 & 4
		fim	$e,4
		jms	arc_tg

		ENDIF

		IF BETTER

; 2 * arc tg (1/3) + arc tg (1/7)

		fim	4,3		; prepare 3 & 9
		fim	$e,9
		jms	arc_tg

		jms	mul2

		fim	4,7		; prepare 4 & 49
		fim	$e,49
		jms	arc_tg

		ENDIF		

		IF MACHIN

; 4 * arc tg (1/5) - arc tg (1/239)

		fim	4,5		; prepare 5 & 25
		fim	$e,25
		jms	arc_tg

		jms	mul2
		jms	mul2

		fim	4,239		; prepare 239 
		fim	$e,239
		ldm	1
		jms	arc_tg_m

		ENDIF

		ldm	0		; clear the integer digit
		xch	$b

		jms	mul2		; multiply by 4
		jms	mul2

		IF	DISPLAY
		fim	0,SD_OFF
		jms	dsp_set
		ENDIF

		fim	0,$20		; save Pi in binary
		fim	2,$00
		jms	mov_xy

;---------------------------------------------------------------------------------------------------
; conversion from binary to decimal
;---------------------------------------------------------------------------------------------------
		fim	4,$30

		src	4
		xch	$b		; write the first digit into status char
		wr0

mul10_loop:	ldm	0
		xch	$b

		xch	5
		dac
		xch	5
		
		fim	0,$10		; multiply by 10 = 2*(2*2+1)
		fim	2,$00			
		jms	mov_xy		
		jms	mul2
		jms	mul2
		fim	0,$00
		fim	2,$10			
		jms	add_xy
		tcc
		add	$b
		xch	$b
		jms	mul2
		xch	$b

		src	4		; write the result
		wrm
		
		ld	5
		jnz	mul10_loop

		fim	0,$00		; clean the remaining part of decimal conversion
		jms	storez
		inc	0
		jms	storez

		IF	DISPLAY
;---------------------------------------------------------------------------------------------------
; Display the result in a 7 segment display
;
; Register usage:
;
; r0,r1		ROM table pointer, segment data
; r2,r3		ROM source pointer
; r4,r5		RAM pointer (source register)
; r6,r7		Wait counter
;---------------------------------------------------------------------------------------------------
		
dsp_main:	fim	0,SD_P		; P
		jms	dsp_pattern

		fim	0,SD_i		; i
		jms	dsp_pattern

		fim	4,$30
		src	4

		rd0
		stc
		jms	dsp_digit

dsp_loop:	xch	5
		dac
		xch	5
		
		src	4		; read the next digit
		rdm
		clc
		jms	dsp_digit
		
		ld	5
		jnz	dsp_loop

		fim	0,SD_OFF	; off 
		jms	dsp_pattern

		jun	dsp_main

dsp_digit:	fim	0,digit_table	; fetch digit pattern from table
		xch	1
		fin	0

		jnc	dsp_pattern
		
		ld	0		; switch on digit point
		ral
		stc
		rar
		xch	0

dsp_pattern:	fim	6,$B6		; display pattern with long wait
		jms	dsp_do
		fim	6,$F0		; display off with short wait
		fim	0,SD_OFF
		
dsp_do:		jms	dsp_set

dsp_wait:	isz	3,dsp_wait
		isz	7,dsp_wait
		isz	6,dsp_wait
		bbl	0

dsp_reg0:	fim	0,0		; read 0
		src	0
		rdm

		fim	0,digit_table	; fetch digit pattern from table
		xch	1
		fin	0

dsp_set:	fim	2,$60		; ROM6 Port
		src	2
		ld	0
		wrr
		
		fim	2,$50		; ROM5 Port
		src	2
		ld	1
		wrr
		bbl	0

;---------------------------------------------------------------------------------------------------
; 7 Segment display data:
;	ROM5 Port:DFEG (lower 4 bits)
;	ROM6 Port:PBCA (upper 4 bits) (P=Digit point)
;---------------------------------------------------------------------------------------------------
digit_t0:
		org	(digit_t0+$F) AND $FF0

			;PBCADFEG 	; PGFEDCBA	
digit_table:	DB	%01111110	; 00111111b	; Digit 0
		DB	%01100000	; 00000110b	; Digit 1
		DB	%01011011	; 01011011b	; Digit 2
		DB	%01111001	; 01001111b	; Digit 3
		DB	%01100101	; 01100110b	; Digit 4
		DB	%00111101	; 01101101b	; Digit 5
		DB	%00111111	; 01111101b	; Digit 6
		DB	%01110000	; 00000111b	; Digit 7
		DB	%01111111	; 01111111b	; Digit 8
		DB	%01111101	; 01101111b	; Digit 9
		DB	%01110111	; 01110111b	; Digit A
		DB	%00101111	; 01111100b	; Digit B
		DB	%00011110	; 00111001b	; Digit C
		DB	%01101011	; 01011110b	; Digit D
		DB	%00011111	; 01111001b	; Digit E
		DB	%00010111	; 01110001b	; Digit F
SD_P:		EQU	%01010111	; 01110011b	; P
SD_i:		EQU	%00100000	; 00000100b	; i
SD_ON:		EQU	%11111111	; 11111111b	; ON
SD_OFF:		EQU	%00000000	; 00000000b	; OFF

		ELSE
		
prg_end:	jms	prg_end

		ENDIF

		end
