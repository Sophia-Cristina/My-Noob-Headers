;---------------------------------------------------------------------------------------------------
;
; Calculating Pi using the inverse tangent formula with Intel 4004 CPU (MCS-4 system) to 305 digits.
;
; Written by Lajos Kintli during February-March of 2023.
;
; (version 2023.03.12)
;
;---------------------------------------------------------------------------------------------------
;
; Used formulas:
;
;	Euler:		Pi/4 = arc tg (1/2) + arc tg (1/3)
;
;	Better:		Pi/4 = 2 * arc tg (1/3) + arc tg (1/7)
;
;	Machin's:	Pi/4 = 4 * arc tg (1/5) - arc tg (1/239)
;
; Inverse tangent is calculated using the Taylor polynomial: 
;
;	arc tg(x)=x - x^3/3 + x^5/5 - x^7/7 + x^9/9 - x^11/11 + ...,
;
; what works for an integer reciprocal in the below way (x=1/n):
;  
;	arc tg(1/n)=1/n - 1/n^3/3 + 1/n^5/5 - 1/n^7/7 + 1/n^9/9 - 1/n^11/11 + ...
;
; Three high level registers are implemented, REG0 is for the sum, REG1 is for the next item
; in Taylor polynomial: 1/n^(2*k+1)/(2*k+1), while REG2 is for 1/n^(2*k+1). 
;
; Precision is 16*16*4 (1024) bits in binary. During the arc tg calculation the integer part of
; the number is zero, only fractional part is stored in memory cells (decimal point is fixed
; before the first memory cell). 
;
; REG2 is started with 1/n, and divided by n*n at every iterations. REG1 is coming
; from REG2 divided by (2*k+1).
;
; Binary result is converted to decimal at the end to 304 digits behind the decimal point,
; thus altogether we have 305 digits with the leading "3".
;
; Most of the calculation time is spent in division routine. It is multiplicated for 4, 8, 12 and
; 16 bits dividers. Additionally as the REG1/REG2 registers converge to zero during the iterations,
; the real divisions are executed only in the remaining part of the registers, continuously on
; shorter numbers.
;
; i4004 register usage:
;
; r0,r1		RAM pointer (SRC value)
; r2,r3		number length pointer
; r4,r5,r6,r7	divider
; r8		tmp for dcl
; r9		bit counter
; ra		next 4 bits
; rb		sign bit or digit
; rc,rd,re,rf	used for divide
;
; RAM content during calculations:
;
; ram 0, row0	status 3,2,1,0: n*n
; ram 0, row2	status 3,2,1,0: 2*k+1
;
; ram 0-3:	REG0: sum
; ram 4-7:	REG1: 1/n^(2*k+1)/(2*k+1)
; ram 8-11:	REG2: 1/n^(2*k+1)
;
; RAM content at the end:
; ram 0-3:	REG0: used for binary to decimal conversion, remaining part
; ram 4-6:	zero
; ram 7-11:	result in decimal (304 digits behind the decimal point)
; ram 12-15:	result in binary (backup)
;
; Decimal result in ram:
;
; RAM 7:
;       0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 - 0 0 0 0	; <-- unconverted line
;       2 6 0 2 4 9 1 4 1 2 7 3 7 2 4 5 - 0 0 0 0	; <-- last decimals
;       4 3 2 6 6 4 8 2 1 3 3 9 3 6 0 7 - 0 0 0 0
;       6 6 9 2 3 4 6 0 3 4 8 6 1 0 4 5 - 0 0 0 0
; RAM 8:
;       2 7 1 2 0 1 9 0 9 1 4 5 6 4 8 5 - 0 0 0 0
;       5 6 4 8 2 3 3 7 8 6 7 8 3 1 6 5 - 0 0 0 0
;       7 5 6 6 5 9 3 3 4 4 6 1 2 8 4 7 - 0 0 0 0
;       9 3 0 3 8 1 9 6 4 4 2 8 8 1 0 9 - 0 0 0 0
; RAM 9:
;       5 5 5 9 6 4 4 6 2 2 9 4 8 9 5 4 - 0 0 0 0
;       8 4 1 0 2 7 0 1 9 3 8 5 2 1 1 0 - 0 0 0 0
;       4 0 8 1 2 8 4 8 1 1 1 7 4 5 0 2 - 0 0 0 0
;       9 5 5 0 5 8 2 2 3 1 7 2 5 3 5 9 - 0 0 0 0
; RAM 10:
;       8 2 3 0 6 6 4 7 0 9 3 8 4 4 6 0 - 0 0 0 0
;       0 6 7 9 8 2 1 4 8 0 8 6 5 1 3 2 - 0 0 0 0
;       8 6 2 8 0 3 4 8 2 5 3 4 2 1 1 7 - 0 0 0 0
;       0 7 8 1 6 4 0 6 2 8 6 2 0 8 9 9 - 0 0 0 0
; RAM 11:
;       1 0 5 8 2 0 9 7 4 9 4 4 5 9 2 3 - 0 0 0 0
;       2 8 8 4 1 9 7 1 6 9 3 9 9 3 7 5 - 0 0 0 0
;       3 8 4 6 2 6 4 3 3 8 3 2 7 9 5 0 - 0 0 0 0
;       1 4 1 5 9 2 6 5 3 5 8 9 7 9 3 2 - 0 0 0 3	; <-- first decimals
;
; Theoretically 1024 bits binary storage means 1024*ln(2)/ln(10)=308.25 decimal digits precision,
; thus few digits may be ruined at the end of the number due to the truncation of the number to a
; finite length. Furthermore, inaccuracy of the first iterations may explode in later iterations,
; but since inverse tangent has alternation with plus and minus of the next tags in the polynomial,
; the error is partly compensated.
;
; The real accuracy can be checked. if the decimal conversion is continued with more digits and
; compared against the theoretical values:
;
; Further 16 digits (digits 305 - 320 at first line of RAM 7) would be:
;
;       8 7 0 1 9 7 2 3 2 2 0 8 2 1 2 2 - 0 0 0 0	<-- RAM 7 first line
;	8 7 0 0 6 6 0 6 3 1 5 5 8 8 1 7			<-- theoretical digits
;
; The first inaccurate digit would come at position 308, the converted 304 digits are correct.
;
; Total calculation time using Machin's formula with 1024 bits accuracy at 740 kHz CLK is 153 sec
; (~126 sec is the calculation in binary, ~27 sec is the decimal conversion)
;
; method	calculation	total
; --------------------------------------
; EULER 	309 sec		336 sec
; BETTER	193 sec		220 sec
; MACHIN	126 sec		153 sec
;
;---------------------------------------------------------------------------------------------------

FIMLEN		EQU	$00

; Set one of the below definitions to 1!

EULER		EQU	0
BETTER		EQU	0
MACHIN		EQU	1

		org	0

		nop
		jun	start

;---------------------------------------------------------------------------------------------------
; Divide by a 4 bit value in r7:	[DST] = [DST] / reg7
;---------------------------------------------------------------------------------------------------
div_r:		clb

div_r_set:	xch	$a

		ld	2
		xch	0
		ld	3
		xch	1
		jun	div_r_skpdec

div_r_dloop:	xch	1	; data loop
		dac
		xch	1
		jc	div_r_skpdec
		xch	0
		dac
		xch	0
div_r_skpdec:	src	0

		ldm	$c	; 4 bit counter
		xch	9

		rdm		; fetch next 4 bits into ra
		xch	$a
		
div_r_bloop:	clc		; bit loop
		xch	$a
		ral		; rotate accu - ra left by one bit
		xch	$a
		ral
		jc	div_r_sub
		
		sub	7	; try to sub the number
		jc	div_r_sub_ok
		
		add	7	; add back the number
		jun	div_r_skip

div_r_sub:	clc
		sub	7	; sub the number in case of carry
div_r_sub_ok:	inc	$a

div_r_skip:	isz	9,div_r_bloop

		xch	$a
		wrm

		ld	1
		jnz	div_r_dloop
	IF	FIMLEN
		clc
		ldm	16 - (FIMLEN/16)	
		add	0
	ELSE
		ld	0
	ENDIF
		jnz	div_r_dloop

		bbl	0

;---------------------------------------------------------------------------------------------------
; Divide 1 by an 8 bit value in r6,r7:	REG2 = 1 / reg6-reg7
;---------------------------------------------------------------------------------------------------
div_x_one	jms	storez

		ld	6
		jnz	div_rr_one

div_r_one:	ldm	1
		jun	div_r_set

div_rr_one:	fim	$e,1
		jun	div_rr_set

;---------------------------------------------------------------------------------------------------
; Divide by a 16 bit value in r4,r5,r6,r7:	[DST] = [DST] / reg4-reg5-reg6-reg7
;---------------------------------------------------------------------------------------------------
div_16:		jun	div_rrrr

div_x:		ld	4
		jnz	div_16
		ld	5
		jnz	div_rrr
		ld	6
		jz	div_r

;---------------------------------------------------------------------------------------------------
; Divide by an 8 bit value in r6,r7:	[DST] = [DST] / reg6-reg7
;---------------------------------------------------------------------------------------------------
div_rr:		fim	$e,0	; clear number
div_rr_set:	
		ld	2
		xch	0
		ld	3
		xch	1
		jun	div_rr_skpdec

div_rr_dloop:	xch	1	; data loop
		dac
		xch	1
		jc	div_rr_skpdec
		xch	0
		dac
		xch	0
div_rr_skpdec:	src	0

		rdm		; fetch next 4 bits into ra
		xch	$a

		ldm	$c	; 4 bit counter
		xch	9
		
div_rr_bloop:	clc		; bit loop
		xch	$a
		ral		; rotate re - rf - ra left by one bit
		xch	$a
		xch	$f
		ral
		xch	$f
		xch	$e
		ral
		xch	$e
		
		jc	div_rr_sub
		
		xch	$f	; try to sub the number
		sub	7
		xch	$f
		cmc
		xch	$e
		sub	6
		xch	$e

		jc	div_rr_sub_ok
		
		xch	$f	; add back the number
		add	7
		xch	$f
		xch	$e
		add	6
		xch	$e

		jun	div_rr_skip

div_rr_sub:	clc		; sub the number in case of carry
		xch	$f
		sub	7
		xch	$f
		cmc
		xch	$e
		sub	6
		xch	$e

div_rr_sub_ok:	inc	$a

div_rr_skip:	isz	9,div_rr_bloop

		xch	$a
		wrm

		ld	1
		jnz	div_rr_dloop
	IF	FIMLEN
		clc
		ldm	16 - (FIMLEN/16)	
		add	0
	ELSE
		ld	0
	ENDIF
		jnz	div_rr_dloop

		bbl	0

;---------------------------------------------------------------------------------------------------
; Divide by a 12 bit value in r5,r6,r7:	[DST] = [DST] / reg5-reg6-reg7
;---------------------------------------------------------------------------------------------------
div_rrr:	fim	$c,0	; clear number
		fim	$e,0

		ld	2
		xch	0
		ld	3
		xch	1
		jun	div_rrr_skpdec

div_rrr_dloop:	xch	1	; data loop
		dac
		xch	1
		jc	div_rrr_skpdec
		xch	0
		dac
		xch	0
div_rrr_skpdec:	src	0

		rdm		; fetch next 4 bits into ra
		xch	$a

		ldm	$c	; 4 bit counter
		xch	9
		
div_rrr_bloop:	clc		; bit loop
		xch	$a
		ral		; rotate rd - re - rf - ra left by one bit
		xch	$a
		xch	$f
		ral
		xch	$f
		xch	$e
		ral
		xch	$e
		xch	$d
		ral
		xch	$d
		
		jc	div_rrr_sub
		
		xch	$f	; try to sub the number
		sub	7
		xch	$f
		cmc
		xch	$e
		sub	6
		xch	$e
		cmc
		xch	$d
		sub	5
		xch	$d

		jc	div_rrr_sub_ok
		
		xch	$f	; add back the number
		add	7
		xch	$f
		xch	$e
		add	6
		xch	$e
		xch	$d
		add	5
		xch	$d

		jun	div_rrr_skip

div_rrr_sub:	clc		; sub the number in case of carry
		xch	$f
		sub	7
		xch	$f
		cmc
		xch	$e
		sub	6
		xch	$e
		cmc
		xch	$d
		sub	5
		xch	$d

div_rrr_sub_ok:	inc	$a

div_rrr_skip:	isz	9,div_rrr_bloop

		xch	$a
		wrm

		ld	1
		jnz	div_rrr_dloop
	IF	FIMLEN
		clc
		ldm	16 - (FIMLEN/16)	
		add	0
	ELSE
		ld	0
	ENDIF
		jnz	div_rrr_dloop

		bbl	0

		org	$100

;---------------------------------------------------------------------------------------------------
; calculate arc tg (1/n)
; in: r6,r7 = n
; in: rc,rd,re,rf = n*n, saced into ram0 status char
;---------------------------------------------------------------------------------------------------
arc_tg:		ldm	0
arc_tg_m:	xch	$b

		fim	2,$FF

		clb
		dcl

		fim	0,$00		; n*n
		src	0
		xch	$f
		wr0
		xch	$e
		wr1
		xch	$d
		wr2
		xch	$c
		wr3

		fim	0,$20		; k = 1
		src	0
		clb
		wr3
		wr2
		wr1
		iac
		wr0

		ldm	2
		dcl		
		jms	div_x_one	; REG2 =  1/n
		
		fim	8,$12		; REG1 = REG2
		jms	mov_xy

atg_loop:	inc	$b		; alternate add/sub functions
		ld	$b
		rar
		jnc	atg_sub
		
		jms	add_xy		; REG0 = REG0 + REG1
		jun	atg_next

atg_sub:	jms	sub_xy		; REG0 = REG0 - REG1

atg_next:	clb			; next (2*k+1)
		dcl
		fim	0,$20
		src	0
		rd0
		add	0
		wr0
		rd1
		add	1
		wr1
		rd2
		add	1
		wr2

		fim	0,$00		; REG2 = REG2 / n * n
		ldm	2
		jms	div_xy
		
atg_dec_len:	src	2
		rdm
		jnz	atg_skplenchk
		
		ld	3
		jnz	atg_declen
	IF FIMLEN		
		clc
		ldm	16 - (FIMLEN/16)	
		add	2
	ELSE
		ld	2	
	ENDIF
		jz	atg_exit

atg_declen:	xch	3
		dac
		xch	3
		jc	atg_dec_len
		xch	2
		dac
		xch	2
		jun	atg_dec_len

atg_skplenchk:	fim	8,$12		; REG1 = REG2
		jms	mov_xy

		fim	0,$20		; REG1 = REG1 / (2*k+1)
		ldm	1
		jms	div_xy

atg_divend:	fim	0,FIMLEN
atg_chk_loop:	src	0		; Check if REG1 is zero
		rdm
		jnz	atg_loop
		isz	1,atg_chk_loop
		isz	0,atg_chk_loop

atg_exit:	bbl	0		; return, if number is zero
		
div_xy:		xch	8
		clb
		dcl
		src	0
		rd0
		xch	7
		rd1
		xch	6
		rd2
		xch	5
		rd3
		xch	4

		ld	8
		dcl
		jun	div_x

;---------------------------------------------------------------------------------------------------
; STORE: [DST] = 0
;---------------------------------------------------------------------------------------------------
storez:		ldm	0
		fim	0,FIMLEN
store_loop:	src	0
		wrm
		isz	1,store_loop
		isz	0,store_loop
		bbl	0
		
;---------------------------------------------------------------------------------------------------
; MOV: [DST] = [SRC]
;---------------------------------------------------------------------------------------------------
mov_xy:		fim	0,FIMLEN
mov_loop:	xch	9
		dcl
		xch	9
		src	0
		rdm
		xch	8
		dcl
		xch	8
		src	0
		wrm
		isz	1,mov_loop
		isz	0,mov_loop
		bbl	0

;---------------------------------------------------------------------------------------------------
; ADD: REG0 = REG0 + REG1
;---------------------------------------------------------------------------------------------------
add_xy:		clb
		fim	0,FIMLEN
		xch	8

add_loop:	ldm	1
		dcl
		src	0
		rdm
		xch	8
		dcl
		xch	8
		src	0
		adm
		wrm
		isz	1,add_loop
		isz	0,add_loop
		bbl	0

;---------------------------------------------------------------------------------------------------
; SUB: REG0 = REG0 - REG1
;---------------------------------------------------------------------------------------------------
sub_xy:		clb
		fim	0,FIMLEN
		dcl
		fim	8,$10

sub_loop:	src	0
		rdm
		xch	8
		dcl
		xch	8
		src	0
		sbm
		cmc
		xch	9
		dcl
		xch	9
		src	0
		wrm
		isz	1,sub_loop
		isz	0,sub_loop
		bbl	0

;---------------------------------------------------------------------------------------------------
; multiply by 2 - REG0 = 2 * REG0,  extra bits are in regB
;---------------------------------------------------------------------------------------------------
mul2:		clb
		dcl
		fim	0,FIMLEN

mul2_loop:	src	0
		rdm
		ral
		wrm
		isz	1,mul2_loop
		isz	0,mul2_loop

		ld	$b
		ral
		xch	$b
		bbl	0	

;---------------------------------------------------------------------------------------------------
; multiply by 2 - REG0 = 2 * REG0,  extra bits are in regB
;---------------------------------------------------------------------------------------------------
mul10:		clb
		dcl
		fim	0,FIMLEN
		xch	$b

mul10_loop:	src	0
		rdm
		ral		; 2
		xch	3
		tcc
		xch	2

		xch	3	; 2 x 2
		ral
		xch	3
		xch	2
		ral
		xch	2

		xch	3	; 2 x 2 + 1
		adm
		xch	3
		tcc
		add	2
		xch	2

		xch	3	; 2 x (2 x 2 + 1)
		ral
		xch	3
		xch	2
		ral
		xch	2

		xch	3	; + digit
		add	$b
		wrm
		tcc
		add	2
		xch	$b

		isz	1,mul10_loop
		isz	0,mul10_loop

		bbl	0	

		org	$200

;---------------------------------------------------------------------------------------------------
; Divide by a 16 bit value in r4,r5,r6,r7:	[DST] = [DST] / reg4-reg5-reg6-reg7
;---------------------------------------------------------------------------------------------------
div_rrrr:	fim	$c,0	; clear number
		fim	$e,0

		ld	2
		xch	0
		ld	3
		xch	1
		jun	div_rrrr_skpdc

div_rrrr_dloop:	xch	1	; data loop
		dac
		xch	1
		jc	div_rrrr_skpdc
		xch	0
		dac
		xch	0
div_rrrr_skpdc:	src	0

		rdm		; fetch next 4 bits into ra
		xch	$a

		ldm	$c	; 4 bit counter
		xch	9
		
div_rrrr_bloop:	clc		; bit loop
		xch	$a
		ral		; rotate rc - rd - re - rf - ra left by one bit
		xch	$a
		xch	$f
		ral
		xch	$f
		xch	$e
		ral
		xch	$e
		xch	$d
		ral
		xch	$d
		xch	$c
		ral
		xch	$c
		
		jc	div_rrrr_sub
		
		xch	$f	; try to sub the number
		sub	7
		xch	$f
		cmc
		xch	$e
		sub	6
		xch	$e
		cmc
		xch	$d
		sub	5
		xch	$d
		cmc
		xch	$c
		sub	4
		xch	$c

		jc	div_rrrr_subok
		
		xch	$f	; add back the number
		add	7
		xch	$f
		xch	$e
		add	6
		xch	$e
		xch	$d
		add	5
		xch	$d
		xch	$c
		add	4
		xch	$c

		jun	div_rrrr_skip

div_rrrr_sub:	clc		; sub the number in case of carry
		xch	$f
		sub	7
		xch	$f
		cmc
		xch	$e
		sub	6
		xch	$e
		cmc
		xch	$d
		sub	5
		xch	$d
		cmc
		xch	$c
		sub	4
		xch	$c

div_rrrr_subok:	inc	$a

div_rrrr_skip:	isz	9,div_rrrr_bloop

		xch	$a
		wrm

		ld	1
		jnz	div_rrrr_dloop
	IF	FIMLEN
		clc
		ldm	16 - (FIMLEN/16)	
		add	0
	ELSE
		ld	0
	ENDIF
		jnz	div_rrrr_dloop

		bbl	0

;---------------------------------------------------------------------------------------------------
; conversion from binary to decimal
; r6 : DCL
; r7 : length 
;---------------------------------------------------------------------------------------------------
bin2dec:	fim	4,0

b2d_loop:	xch	5		; decrement pointer
		dac
		xch	5
		jc	b2d_skpdec
		
		xch	4
		dac
		xch	4
b2d_skpdec:	
		jms	mul10
		ld	6
		dcl
		src	4		; write the result
		xch	$b
		wrm

		ld	5
		jnz	b2d_loop

		clc
		ld	7	
		add	4

		jnz	b2d_loop
		
		bbl	0

;---------------------------------------------------------------------------------------------------
; main program
;---------------------------------------------------------------------------------------------------
start:		clb
		dcl
		jms	storez

		IF EULER

; arc tg (1/2) + arc tg (1/3)

		fim	6,3		; prepare 3 & 9
		fim	$c,0
		fim	$e,9
		jms	arc_tg

		fim	6,2		; prepare 2 & 4
		fim	$c,0
		fim	$e,4
		jms	arc_tg

		ENDIF

		IF BETTER

; 2 * arc tg (1/3) + arc tg (1/7)

		fim	6,3		; prepare 3 & 9
		fim	$c,0
		fim	$e,9
		jms	arc_tg

		jms	mul2

		fim	6,7		; prepare 4 & 49
		fim	$c,0
		fim	$e,49
		jms	arc_tg

		ENDIF		

		IF MACHIN

; 4 * arc tg (1/5) - arc tg (1/239)

		fim	6,5		; prepare 5 & 25
		fim	$c,0
		fim	$e,25
		jms	arc_tg

		jms	mul2
		jms	mul2

		fim	6,239		; prepare 239 
		fim	$c,(239*239/256)
		fim	$e,(239*239)
		ldm	1
		jms	arc_tg_m

		ENDIF

		ldm	0		; clear the integer digit
		xch	$b

		jms	mul2		; multiply by 4
		jms	mul2

;---------------------------------------------------------------------------------------------------
; Save the result in decimal into the memory
;---------------------------------------------------------------------------------------------------
		fim	8,$30		; save the binary result to "REG3"
		jms	mov_xy		; not used, just for reference

		ldm	2		; save the first digit into status char
		dcl
		fim	4,$FF
		src	4
		xch	$b
		wr0

	IF FIMLEN
		fim	6,$20 + (16 - (FIMLEN/16))
		jms	bin2dec	
	ELSE
		fim	6,$20		; 256 decimals are saved into REG2
		jms	bin2dec	
		fim	6,$13		; further 48 decimals are saved into REG1
		jms	bin2dec	
	ENDIF

;		clb			; clean the remaining part of decimal conversion
;		dcl
;		jms	storez

prg_end:	jms	prg_end

		end